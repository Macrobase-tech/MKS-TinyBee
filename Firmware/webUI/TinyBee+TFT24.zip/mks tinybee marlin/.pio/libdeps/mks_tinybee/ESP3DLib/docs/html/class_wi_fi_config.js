var class_wi_fi_config =
[
    [ "WiFiConfig", "class_wi_fi_config.html#ab7ecc980e32d91b9e71d96dc1b040092", null ],
    [ "~WiFiConfig", "class_wi_fi_config.html#afa73eed5ba10b1b86da8013bca38c0b9", null ]
];