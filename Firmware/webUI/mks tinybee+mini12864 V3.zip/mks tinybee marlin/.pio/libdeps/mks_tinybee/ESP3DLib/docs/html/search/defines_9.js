var searchData=
[
  ['rxbuffersize_294',['RXBUFFERSIZE',['../serial2socket_8h.html#a29d12c67e4b6e0ff96d7aa793757b094',1,'serial2socket.h']]]
];
