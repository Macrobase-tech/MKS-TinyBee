var searchData=
[
  ['serial_5f2_5fsocket_214',['Serial_2_Socket',['../class_serial__2___socket.html#a342b89d67032d2e8ec97afefa4819f32',1,'Serial_2_Socket']]],
  ['size_215',['size',['../class_e_s_p___s_d.html#abf4072cccbb5a4ef00a32e28998a2dcf',1,'ESP_SD']]],
  ['startap_216',['StartAP',['../class_wi_fi_config.html#a0983d19d571709a1ae0e8ef792a3babe',1,'WiFiConfig']]],
  ['startsta_217',['StartSTA',['../class_wi_fi_config.html#a1860d6ab8d817ed15fc32b91cb02ef6f',1,'WiFiConfig']]],
  ['stopwifi_218',['StopWiFi',['../class_wi_fi_config.html#a27890e9bff0d16bacce8c77fbb2404bb',1,'WiFiConfig']]]
];
