var searchData=
[
  ['baudrate_172',['baudRate',['../class_serial__2___socket.html#a32d3054e537d54d14a5d8b5573002602',1,'Serial_2_Socket']]],
  ['begin_173',['begin',['../class_serial__2___socket.html#a5fd33907b0c6db7390f899eaa2b20848',1,'Serial_2_Socket::begin()'],['../class_web___server.html#a856e18f69bf41ae5cb0c530d63823f39',1,'Web_Server::begin()'],['../class_wi_fi_config.html#a6f2a31ecc4a60bee3835d23b374e7ab7',1,'WiFiConfig::begin()'],['../class_wi_fi_services.html#a33ed941b1c764817764807acf6c82557',1,'WiFiServices::begin()']]]
];
