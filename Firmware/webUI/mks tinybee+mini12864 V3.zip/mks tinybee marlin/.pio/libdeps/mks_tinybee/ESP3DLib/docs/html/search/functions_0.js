var searchData=
[
  ['attachws_170',['attachWS',['../class_serial__2___socket.html#a2d179a197b7735d79dba9409f1efd9a7',1,'Serial_2_Socket']]],
  ['available_171',['available',['../class_e_s_p___s_d.html#a3474b13136a71ab6ea2afbe14025d9f9',1,'ESP_SD::available()'],['../class_serial__2___socket.html#a2f94f78cf1a565de82d05307e708ff38',1,'Serial_2_Socket::available()']]]
];
