var serial2socket_8h =
[
    [ "Serial_2_Socket", "class_serial__2___socket.html", "class_serial__2___socket" ],
    [ "FLUSHTIMEOUT", "serial2socket_8h.html#a4731ef512b433abe9b4c9e709c214ace", null ],
    [ "RXBUFFERSIZE", "serial2socket_8h.html#a29d12c67e4b6e0ff96d7aa793757b094", null ],
    [ "TXBUFFERSIZE", "serial2socket_8h.html#a8c651ff98c42106f3a14ee4225677cc8", null ],
    [ "Serial2Socket", "serial2socket_8h.html#aa7804a9d5cfd98917275be16a5d6556a", null ]
];